var homeTopItems = [
	{
		title:'热门',
		icon:'heme-top1.png',
		type:1
	},
		{
		title:'打听',
		icon:'heme-top2.png',
		type:11
	},
		{
		title:'吐槽',
		icon:'heme-top3.png',
		type:12
	},
		{
		title:'公告',
		icon:'heme-top4.png',
		type:13
	},

];